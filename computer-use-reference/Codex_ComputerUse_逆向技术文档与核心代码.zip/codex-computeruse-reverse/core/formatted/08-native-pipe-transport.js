// C08: installed source, /Applications/ChatGPT.app/Contents/Resources/cua_node/lib/node_modules/@oai/sky/dist/project/cua/sky_js/src/targets/mac/native-pipe.js
// Formatting only. Imports keep their original relative paths; this extracted copy is for reading.
import { __awaiter as e, __classPrivateFieldGet as t, __classPrivateFieldSet as n } from "../../../../../../lib/js/oai_js/node_modules/tslib/tslib.es6.js";
import { Buffer as r } from "node:buffer";
import * as o from "node:fs";
import { homedir as i } from "node:os";
import s from "node:path";
import { SkyComputerUseTransportError as c, SkyComputerUseError as a, ServerErrorCode as u } from "./errors.js";
var l, f, p, h, d, m, y, v, w, S, C, g;
const k = 8388608,
  U = 5e3;
class E {
  static create(t) {
    return e(this, void 0, void 0, function* () {
      const n = O().nativePipe;
      if (null == n || "function" != typeof n.createConnection) throw new c("Sky Computer Use native pipe is unavailable");
      const a = null !== (l = _(null === (u = O().env) || void 0 === u ? void 0 : u.SKY_CUA_SERVICE_NATIVE_PIPE_PATH)) && void 0 !== l ? l : s.join(i(), "Library", "Group Containers", "2DC432GLL2.com.openai.sky.CUAService", "IPC", "computeruse.sock");
      var u, l;
      try {
        return yield this.connect(n.createConnection, a, t, 250);
      } catch (i) {
        if (!(i instanceof q)) throw i;
        try {
          yield function (t) {
            return e(this, void 0, void 0, function* () {
              var e, n, i;
              const c = _(null === (e = t.env) || void 0 === e ? void 0 : e.NODE_REPL_HOST_SERVICES_PIPE_PATH);
              if (null != c) {
                const e = null === (n = t.nativePipe) || void 0 === n ? void 0 : n.createConnection;
                if ("function" != typeof e) throw new Error("Sky Computer Use requires nodeRepl.nativePipe support");
                const o = e(c);
                let i;
                try {
                  i = yield M(o, U, "Sky Computer Use host service connection timed out");
                } catch (e) {
                  throw o.then(e => e.end(), () => {}), e;
                }
                try {
                  yield function (e) {
                    return new Promise((t, n) => {
                      const o = 0;
                      let i = r.alloc(0),
                        s = !1;
                      const c = setTimeout(() => a(new Error("Sky Computer Use host service ensure timed out")), U),
                        a = r => {
                          s || (s = !0, clearTimeout(c), e.off("data", u), e.off("error", l), e.off("close", f), null == r ? t() : n(r));
                        },
                        u = e => {
                          try {
                            i = r.concat([i, r.from(e)]);
                            const t = P(i);
                            i = t.remainingData;
                            for (const e of t.messages) {
                              const t = JSON.parse(e);
                              if ("object" == typeof t && null != t && "id" in t && t.id === o) if ("error" in t) {
                                const e = t.error,
                                  n = "object" == typeof e && null != e && "message" in e && "string" == typeof e.message ? e.message : "Sky Computer Use host service ensure failed";
                                a(new Error(n));
                              } else "result" in t ? a() : a(new Error("Sky Computer Use host service returned an invalid response"));
                            }
                          } catch (e) {
                            a(A(e));
                          }
                        },
                        l = e => a(e),
                        f = () => a(new Error("Sky Computer Use host service connection closed before response"));
                      e.on("data", u), e.on("error", l), e.on("close", f);
                      try {
                        e.write(b(JSON.stringify({
                          id: o,
                          jsonrpc: "2.0",
                          method: "ensureService",
                          params: {
                            service: "computer-use"
                          }
                        })));
                      } catch (e) {
                        a(A(e));
                      }
                    });
                  }(i);
                } finally {
                  i.end();
                }
                return;
              }
              const a = null === (i = t.launchServices) || void 0 === i ? void 0 : i.openApplication;
              if ("function" != typeof a) throw new Error("Sky Computer Use requires nodeRepl.launchServices support");
              yield a(function (e) {
                const t = _(null == e ? void 0 : e.SKY_CUA_SERVICE_PATH);
                if (null != t) return {
                  applicationPath: t
                };
                const n = _(null == e ? void 0 : e.CODEX_HOME);
                if (null != n) {
                  const e = s.join(n, "computer-use", "Codex Computer Use.app");
                  if (o.existsSync(e)) return {
                    applicationPath: e
                  };
                }
                return {
                  bundleIdentifier: "com.openai.sky.CUAService"
                };
              }(t.env));
            });
          }(O());
        } catch (e) {
          throw new c("Sky Computer Use service startup request failed", {
            cause: e
          });
        }
        try {
          return yield this.connect(n.createConnection, a, t, 5e3);
        } catch (e) {
          throw new c("Sky Computer Use native pipe startup failed", {
            cause: e
          });
        }
      }
    });
  }
  static connect(n, r, o, i) {
    return e(this, void 0, void 0, function* () {
      const e = Date.now() + i;
      let s;
      for (;;) {
        const i = e - Date.now();
        if (i <= 0) throw new q(s);
        let c;
        const f = n(r);
        try {
          c = yield M(f, i, "Sky Computer Use native pipe connection timed out");
        } catch (e) {
          f.then(e => e.end(), () => {}), s = e;
        }
        if (null != c) {
          const n = new E(c, o);
          try {
            return yield n.ping(Math.min(1e3, Math.max(1, e - Date.now()))), n;
          } catch (e) {
            if (t(n, l, "m", g).call(n), e instanceof D || e instanceof a && e.code === u.incompatibleClientVersion) throw e;
            s = e;
          }
        }
        if (Date.now() >= e) throw new q(s);
        yield R(100);
      }
    });
  }
  constructor(e, o) {
    l.add(this), f.set(this, void 0), p.set(this, 1), h.set(this, r.alloc(0)), d.set(this, new Map()), m.set(this, Promise.resolve()), y.set(this, void 0), n(this, f, o, "f"), n(this, y, e, "f"), e.on("data", n => {
      try {
        t(this, l, "m", w).call(this, n);
      } catch (n) {
        t(this, l, "m", C).call(this, A(n)), e.end();
      }
    }), e.on("error", e => t(this, l, "m", C).call(this, e)), e.on("close", () => t(this, l, "m", C).call(this, new Error("Sky Computer Use native pipe closed before response")));
  }
  get isClosed() {
    return null == t(this, y, "f");
  }
  request(r) {
    return e(this, void 0, void 0, function* () {
      const e = 1e3 * r.timeoutSeconds,
        o = t(this, m, "f").then(() => t(this, l, "m", v).call(this, "request", {
          clientApiVersion: t(this, f, "f"),
          codexTurnMetadata: j(r.codexMetadata),
          deadlineUnixMilliseconds: Date.now() + e,
          request: r.request,
          requestType: r.requestType
        }, e));
      return n(this, m, o.then(() => {}, () => {}), "f"), yield o;
    });
  }
  ping(n) {
    return e(this, void 0, void 0, function* () {
      const e = yield t(this, l, "m", v).call(this, "ping", {
        clientApiVersion: t(this, f, "f")
      }, n);
      if (e.serverApiVersion !== t(this, f, "f")) throw new D(`Sky Computer Use API version mismatch: client=${t(this, f, "f")} server=${String(e.serverApiVersion)}`);
    });
  }
}
function P(e) {
  const t = [];
  let n = 0;
  for (; e.length - n >= 4;) {
    const r = e.readUInt32LE(n);
    if (r > k) throw new c(`Sky Computer Use native pipe frame is too large: ${r}`);
    const o = 4 + r;
    if (e.length - n < o) break;
    t.push(e.subarray(n + 4, n + o).toString("utf8")), n += o;
  }
  return {
    messages: t,
    remainingData: e.subarray(n)
  };
}
function b(e) {
  const t = r.from(e, "utf8");
  if (t.length > k) throw new c(`Sky Computer Use native pipe frame is too large: ${t.length}`);
  const n = r.alloc(4 + t.length);
  return n.writeUInt32LE(t.length, 0), t.copy(n, 4), n;
}
function j(e) {
  return null == e || "object" == typeof e && !ArrayBuffer.isView(e) ? e : JSON.parse(r.from(e).toString("utf8"));
}
function T(e) {
  if ("object" != typeof e || null == e || !("id" in e) || "number" != typeof e.id || !("jsonrpc" in e) || "2.0" !== e.jsonrpc) throw new c("Sky Computer Use returned an invalid JSON-RPC response");
  const t = Object.prototype.hasOwnProperty.call(e, "result");
  if (t === Object.prototype.hasOwnProperty.call(e, "error")) throw new c("Sky Computer Use returned an invalid JSON-RPC response");
  if (t) return {
    id: e.id,
    jsonrpc: "2.0",
    result: Reflect.get(e, "result")
  };
  const n = Reflect.get(e, "error");
  if ("object" != typeof n || null == n || !("code" in n) || "number" != typeof n.code || !("message" in n) || "string" != typeof n.message) throw new c("Sky Computer Use returned an invalid JSON-RPC response");
  return {
    error: {
      code: n.code,
      message: n.message
    },
    id: e.id,
    jsonrpc: "2.0"
  };
}
function O() {
  const e = globalThis.nodeRepl;
  if (null == e) throw new c("Sky Computer Use requires the trusted nodeRepl runtime");
  return e;
}
function _(e) {
  return "string" == typeof e && "" !== e.trim() ? e.trim() : void 0;
}
function A(e) {
  return e instanceof Error ? e : new Error(String(e));
}
function R(e) {
  return new Promise(t => setTimeout(t, e));
}
function M(t, n, r) {
  return e(this, void 0, void 0, function* () {
    let e;
    try {
      return yield Promise.race([t, new Promise((t, o) => {
        e = setTimeout(() => o(new Error(r)), n);
      })]);
    } finally {
      null != e && clearTimeout(e);
    }
  });
}
f = new WeakMap(), p = new WeakMap(), h = new WeakMap(), d = new WeakMap(), m = new WeakMap(), y = new WeakMap(), l = new WeakSet(), v = function (e, r, o) {
  var i, s;
  const a = t(this, y, "f");
  if (null == a) throw new c("Sky Computer Use native pipe is closed");
  const u = (n(this, p, (s = t(this, p, "f"), i = s++, s), "f"), i);
  return new Promise((n, i) => {
    t(this, d, "f").set(u, {
      reject: i,
      resolve: n,
      timeout: setTimeout(() => {
        t(this, l, "m", C).call(this, new c(`Sky Computer Use ${e} timed out`)), a.end();
      }, o)
    });
    try {
      a.write(b(JSON.stringify({
        id: u,
        jsonrpc: "2.0",
        method: e,
        params: r
      })));
    } catch (e) {
      const n = t(this, d, "f").get(u);
      null != n && (t(this, d, "f").delete(u), clearTimeout(n.timeout)), i(A(e));
    }
  });
}, w = function (e) {
  n(this, h, r.concat([t(this, h, "f"), r.from(e)]), "f");
  const o = P(t(this, h, "f"));
  n(this, h, o.remainingData, "f");
  for (const e of o.messages) t(this, l, "m", S).call(this, T(JSON.parse(e)));
}, S = function (e) {
  const n = e.id,
    r = t(this, d, "f").get(n);
  null != r && (t(this, d, "f").delete(n), clearTimeout(r.timeout), "error" in e ? r.reject(new a({
    code: e.error.code,
    message: e.error.message,
    request: null,
    requestType: "jsonRPC"
  })) : r.resolve(e.result));
}, C = function (e) {
  if (null != t(this, y, "f")) {
    n(this, y, null, "f");
    for (const n of t(this, d, "f").values()) clearTimeout(n.timeout), n.reject(e);
    t(this, d, "f").clear();
  }
}, g = function () {
  const e = t(this, y, "f");
  n(this, y, null, "f"), null == e || e.end();
};
class q extends Error {
  constructor(e) {
    var t;
    super(`Sky Computer Use native pipe is unavailable: ${t = e, t instanceof Error ? t.message : String(t)}`);
  }
}
class D extends c {}
export { E as MacNativePipeTransport, P as decodeMessageFrames, b as encodeMessageFrame };
