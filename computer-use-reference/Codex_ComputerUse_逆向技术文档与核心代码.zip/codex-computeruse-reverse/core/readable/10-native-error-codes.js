// C10: AST scope-aware renamed reading edition; not a source map or recovered author names.
// Runtime structure, operations, literal values and export names are retained.
// Read beside core/formatted/10-native-error-codes.js. Relative imports are intentionally not vendored.
const ServerErrorCode = {
    senderProcessNotAuthenticated: -1e4,
    couldNotGetRequestData: -10001,
    couldNotGetRequestTypeName: -10002,
    couldNotResolveRequestType: -10003,
    unhandledEvent: -10004,
    unknownError: -10005,
    appNotAllowed: -10006,
    runningApplicationNotFound: -10007,
    accessibilityError: -10008,
    permissionsNotGranted: -10009,
    invalidApp: -10010,
    noActiveSession: -10011,
    userStoppedSession: -10012,
    incompatibleClientVersion: -10013,
    permissionsPending: -10014,
    blockedURL: -10015,
    userIntervened: -10016,
    couldNotGetSenderPID: -10017,
    ambiguousApp: -10018,
    couldNotGetBootstrapPort: -10019,
    screenLocked: -10020
  },
  t = new Map(Object.entries(ServerErrorCode).map(([e, t]) => [t, e]));
class SkyComputerUseError extends Error {
  constructor({
    code: e,
    message: s,
    request: o,
    requestType: r
  }) {
    var n;
    super(s), this.name = "SkyComputerUseError", this.code = e, this.errorName = null !== (n = t.get(e)) && void 0 !== n ? n : "jsonRPCError", this.request = o, this.requestType = r;
  }
}
class SkyComputerUseTransportError extends Error {
  constructor(e, t = {}) {
    super(e), this.name = "SkyComputerUseTransportError", this.cause = t.cause;
  }
}
export { ServerErrorCode, SkyComputerUseError, SkyComputerUseTransportError };
